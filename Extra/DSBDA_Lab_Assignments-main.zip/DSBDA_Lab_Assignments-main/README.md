# DSBDA_Lab_Assignments
List of DSBDA practical assignments 
Each folder contains the problem statement as a text file.The code is in the form of a jupyter notebook.
